package edu.kcg.Poker.Table.DataManager;

abstract public class AdaptManager implements CardsManagerInterface,
		ChipsManagerInterFace, PhasesManagerInterface, PlayersManagerInterface {
}
