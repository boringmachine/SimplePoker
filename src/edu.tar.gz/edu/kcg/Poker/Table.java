package edu.kcg.Poker;

import java.util.ArrayList;
/**
 * ポーカーのゲームテーブル。ゲームに使用するデータを持つ。
 * このデータはPokerGameクラスのメソッドから処理される。
 * つまり、テーブルとゲームを分離することで、処理とデータを分離している。
 * @author john
 *
 */
public class Table{
	private static int lastId = 0;
	public static final char[] MARK = {'H','C','D','S'};
	//テーブルのId
	private int tableId;
	//席
	private ArrayList<Chair> chairs;
	//ラウンド番号
	private int round;
	//現在プレイしているプレイヤーの番号
	private int currentPlayer;
	//参加費
	private int anty;
	//ベットの上限
	private int limit;
	//ポット
	private int pot;
	//現在の掛け金の最大値
	private int maxBet;
	//山札
	private int[] deck = new int[52];
	//山札の一番上のカードのインデックス
	private int deckIndex;
	//コミュニティカード
	private int[] communityCards = new int[5];
	//コミュニティカードのインデックス
	private int communityCardsIndex;
	//現在のディーラーのプレイヤー番号
	private int dealer;
	//現在のフェーズ種類
	private int currentPhase;
		
	public Table(){
		chairs  = new ArrayList<Chair>();
		tableId = lastId++;
		currentPlayer=0;
		dealer = 0;
		anty = 1;
		limit = Integer.MAX_VALUE;
		pot = 0;
		maxBet = 0;
		deckIndex = 0;		
		communityCardsIndex = 0;
		for(int i=0;i<this.communityCards.length;i++){
			communityCards[i] = -1;
		}
	}
	
	public int getCurrentPhase() {
		return currentPhase;
	}

	public void setCurrentPhase(int currentPhase) {
		this.currentPhase = currentPhase;
	}

	public ArrayList<Chair> getChairs() {
		return chairs;
	}

	public int chairSize(){
		return chairs.size();
	}
	
	public void addChair(Player player){
		chairs.add(new Chair(player));
	}
	
	public int getDeckIndex() {
		return deckIndex;
	}

	public void setDeckIndex(int deckIndex) {
		this.deckIndex = deckIndex;
	}

	public int getCommunityCardsIndex() {
		return communityCardsIndex;
	}

	public void setCommunityCardsIndex(int communityCardsIndex) {
		this.communityCardsIndex = communityCardsIndex;
	}

	/**
	 * ポットを加算。
	 * @return
	 */
	
	public void addPot(int x){
		pot += x;
	}
	
	public void pushCommunityCards(int x){
		this.communityCards[communityCardsIndex++]=x;
	}
	
	public int getCurrentPlayer() {
		return currentPlayer;
	}

	public void setCurrentPlayer(int currentPlayer) {
		this.currentPlayer = currentPlayer;
	}

	public int popDeck(){
		return deck[deckIndex--];
	}
	
	public int getAnty() {
		return anty;
	}
	public void setAnty(int anty) {
		this.anty = anty;
	}
	public int getMaxBet() {
		return maxBet;
	}
	public void setMaxBet(int maxBet) {
		this.maxBet = maxBet;
	}
	public int getRound() {
		return round;
	}
	public void setRound(int round) {
		this.round = round;
	}
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public int getDealer() {
		return dealer;
	}
	public void setDealer(int dealer) {
		this.dealer = dealer;
	}

	public int getTableId() {
		return tableId;
	}

	public int getPot() {
		return pot;
	}
	public int[] getCommunityCards() {
		return communityCards;
	}

	public void setDeck(int[] deck) {
		this.deck = deck;
	}
	
	
}
