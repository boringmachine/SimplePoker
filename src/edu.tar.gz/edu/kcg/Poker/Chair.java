package edu.kcg.Poker;


public class Chair{
	public static final int HANDBITMASK_LEFT = 0x03F;
	public static final int HANDBITMASK_RIGHT = 0xFC0;
	
	private Player player;
	private int hands;
	private int lastPlay;
	private int addedBet;
	private boolean fold ;
	private boolean allin;
	
	public Chair(Player player){
		this.player = player;
		lastPlay = 0;
		addedBet = 0;
		fold = false;
		allin = false;
	}
	public int choice(int maxBet,int limit){
		if(isFold()){
			return -2;
		}
		if(isAllin()){
			return 0;
		}
		int option = player.getStrategy().solveBet();
		if(option>-1){
			int bankroll = player.getBankroll();
			int bet = maxBet - this.addedBet;
			if(bankroll-bet<0){
				bet = bankroll;
				setAllin(true);
			}
			if(bet+maxBet>limit){
				bet = limit - this.addedBet;
			}
			this.addedBet += bet;
			bankroll -= bet;
			player.setBankroll(bankroll);
		}else if(option == -1){
			setFold(true);
		}
		this.setLastPlay(option);
		return option;
	}
	
	public boolean isFold() {
		return fold;
	}
	public void setFold(boolean fold) {
		this.fold = fold;
	}
	public boolean isAllin() {
		return allin;
	}
	public void setAllin(boolean allin) {
		this.allin = allin;
	}
	public void setAddedBet(int addedBet) {
		this.addedBet = addedBet;
	}
	public int getAddedBet() {
		return addedBet;
	}
	public int getLastPlay() {
		return lastPlay;
	}


	public void setLastPlay(int lastPlay) {
		this.lastPlay = lastPlay;
	}

	public Player getPlayer() {
		return player;
	}
	public void setPlayer(Player player) {
		this.player = player;
	}
	public int getHands() {
		return hands;
	}
	public void setHands(int hands) {
		this.hands = hands;
	}
	public void payAnty(int x){
		this.setLastPlay(x);
		this.addedBet+=x;
		player.payAnty(x);
	}
	public void profit(int x){
		player.profit(x);
	}
	
	
}
