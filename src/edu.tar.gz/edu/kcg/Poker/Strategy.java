package edu.kcg.Poker;

public interface Strategy {
	int solveBet();
}
