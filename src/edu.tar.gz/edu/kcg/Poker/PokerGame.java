package edu.kcg.Poker;

import java.util.ArrayList;

public class PokerGame implements GameRules{

	private Table table;
	
	public PokerGame(Table table){
		this.table = table;
	}

	/**
	 * 処理をするテーブルを設定。
	 * 
	 * @param table
	 */
	public void setTable(Table table){
		this.table = table;
	}
	/**
	 * 参加プレイヤーを追加する。
	 * @param player 追加するプレイヤー。
	 */
	public void addPlayer(Player player){
		table.addChair(player);
	}
	
	/**
	 * ゲーム状態を返す。
	 * @return
	 */
	public int gameStatus(){
		int pot = table.getPot();
		int round = table.getRound();
		if(pot==0){
			return GameRules.FIRST;
		}
		if(round==4){
			return GameRules.FINAL;
		}
		
		for(Chair chair:table.getChairs()){
			if(chair.getLastPlay()>0){
				return GameRules.HUMAN;
			}
		}
		if(table.getCurrentPhase()==GameRules.CHANCE){
			table.setCurrentPhase(GameRules.HUMAN);
			for(Chair chair:table.getChairs()){
				if(!chair.isFold()){
					chair.setLastPlay(1);
				}
			}
			return GameRules.CHANCE;
		}
		return GameRules.CHANCE;
	}
	/**
	 * ゲーム開始
	 */
	public void firstPhase(){
		initGame();
		
		
		int anty = table.getAnty();
		int small = table.getDealer()+1;
		if(small>table.chairSize()-1){
			small = 0;
		}
		int big = small+1;
		if(big>table.chairSize()-1){
			big = 0;
		}
		ArrayList<Chair> chairs = table.getChairs();
		
		Chair smallblind = chairs.get(small); 
		smallblind.payAnty(anty);
		
		Chair bigblind = chairs.get(big);
		bigblind.payAnty(anty*2);


		addPot(anty*3);
		table.setMaxBet(anty*2);
	}
	
	/**
	 * 偶然手番の処理。
	 */
	public void chancePhase(){
		int round = table.getRound();
		round++;
		table.setRound(round);
		if(round==1){
			for(int i=0;i<3;i++){
				int card = table.popDeck();
				table.pushCommunityCards(card);
			}
		}else if(round == 2 || round == 3){
			int card = table.popDeck();
			table.pushCommunityCards(card);
		}else if(round == 4){	
		}
		
		//標準出力 start
		for(int card:table.getCommunityCards()){
			if(card==-1){
				System.out.print("[]");
			}else{
				System.out.print("["+(card%13+1)+":"+Table.MARK[card/13]+"]");
			}
		}
		System.out.println();
		//標準出力 end
	}
	

	/**
	 * 人為手番の処理。
	 */
	public void humanPhase(){
		int i = table.getCurrentPlayer();
		int maxBet = table.getMaxBet();
		int limit = table.getLimit();
		Chair chair = table.getChairs().get(i);
		System.out.println(
				"pot:"+table.getPot()+","+
				"max_bet:"+maxBet+","+
				"your_total_bet:"+chair.getAddedBet());

		int bet = chair.choice(maxBet,limit);
		if(bet>-1){
			table.setMaxBet(bet+maxBet);
			addPot(bet);
		}
	
		//標準出力 start
		int lastplay = chair.getLastPlay();
		String stringLastPlay = String.valueOf(lastplay);
		if(chair.isFold()){
			stringLastPlay = "Fold";
		}else if(chair.isAllin()){
			stringLastPlay = "All In";
		}else if(lastplay==0){
			stringLastPlay = "Call";
		}else{
			stringLastPlay = "Bet"+String.valueOf(lastplay)+"$";
		}
		System.out.println(i+":last_play:"+stringLastPlay);
		//標準出力 end
	}
	
	/**
	 * ゲーム終了
	 */
	public void finalPhase(){
		int winner = 0;
		int max = 0;
		int hand = 0;
		int i = 0;
		ArrayList<Chair> chairs = table.getChairs();
		for(Chair chair:chairs){
			hand = checkHand(chair.getHands());
			if(hand>max){
				max = hand;
				winner = i;
			}
			i++;
		}
		int pot = table.getPot();
		chairs.get(winner).profit(pot);
	}

	
	/**
	 * カードを配る。
	 */
	private void deal(){
		for(Chair chair:table.getChairs()){
			int cardLeft = table.popDeck()<<6;
			int cardRight = table.popDeck();
			int hands = cardLeft+cardRight;
			chair.setHands(hands);
		}
	}
	
	/**
	 * ポットを加算
	 * @param x
	 */
	private void addPot(int x){
		table.addPot(x);
	}
	
	
	
	/**
	 * 次のディーラーを決定。
	 */
	private int nextDealer(){
		int dealer = table.getDealer();
		int playerNum = table.chairSize();
		dealer++;
		if(dealer>playerNum-1){
			dealer=0;
		}
		return 0;
	}

	
	
	/**
	 * ゲームを初期化する。
	 */
	private void initGame(){
		for(Chair chair:table.getChairs()){
			chair.setLastPlay(0);
		}
		table.setMaxBet(0);
		table.setRound(0);
		table.setCommunityCardsIndex(0);
		table.setDeckIndex(51);
		shuffle();
		deal();
		nextDealer();
	}
	/**
	 * デックをシャッフル
	 */
	private void shuffle(){
		int[] bufDeck = new int[52];
		for(int i=0;i<bufDeck.length;i++){
			bufDeck[i] = i;
		}
		
		for(int i=bufDeck.length-1; i>0; i--){
            int t = (int)(Math.random() * i); 
            int tmp = bufDeck[i];
            bufDeck[i]  = bufDeck[t];
            bufDeck[t]  = tmp;
        }
		
		table.setDeck(bufDeck);
	}
	

	/**
	 * ハンドの強さを計算。強いほど大きい。
	 * @return
	 */
	private int checkHand(int hands){
		return 0;
	}
	
	/**
	 * 次のフェーズへ移動する。
	 */
	public int nextPhase(){
		int currentPlayer = table.getCurrentPlayer();
		int playerNum = table.chairSize();
		int currentPhase = this.gameStatus();
		if(currentPhase == GameRules.HUMAN){
			currentPlayer++;
			if(currentPlayer>playerNum-1){
				currentPlayer=0;
			}
		}else{
			currentPlayer = table.getDealer();
		}
		table.setCurrentPlayer(currentPlayer);
		table.setCurrentPhase(currentPhase);
		return currentPhase;
	}
}
