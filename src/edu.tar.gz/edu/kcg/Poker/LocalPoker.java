package edu.kcg.Poker;

public class LocalPoker {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Table table = new Table();		
		Player[] players = new Player[3];
		PokerGame game = new PokerGame(table);
		
		table.setAnty(10);
		table.setLimit(Integer.MAX_VALUE);	
		
		for(Player player:players){
			player = new Player();
			player.setStrategy(new MyStrategy());
			player.setBankroll(Integer.MAX_VALUE);
			game.addPlayer(player);
		}

		int status;
		while(true){
			status=game.gameStatus();
			switch(status){
			case GameRules.FIRST :
				System.out.println("first:");
				game.firstPhase();
				break;
			case GameRules.HUMAN:
				System.out.println("human:");
				game.humanPhase();
				break;
			case GameRules.CHANCE:
				System.out.println("chance:");
				game.chancePhase();
				break;
			case GameRules.FINAL:
				System.out.println("final:");
				game.finalPhase();
				break;
			}
			System.out.println("");
			if(status==GameRules.FINAL){
				break;
			}
			game.nextPhase();
		}
	}

}
