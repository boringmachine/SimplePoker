package edu.kcg.Poker;

public class Player {
	static private int lastId = 0;
	private int playerId;
	private int bankroll;
	private Strategy strategy;

		
	public Player(){
		this.playerId = lastId++;
	}
	
	public Strategy getStrategy(){
		return this.strategy;
	}
	public void setStrategy(Strategy strategy) {
		this.strategy = strategy;
	}

	public int getPlayerId() {
		return playerId;
	}

	public int getBankroll() {
		return bankroll;
	}
	
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public void setBankroll(int bankroll) {
		this.bankroll = bankroll;
	}


	public void profit(int x){
			bankroll+=x;
	}
	
	public int payAnty(int x){
		int anty = x;
		this.bankroll -= anty;
		return anty;
	}
	
}
