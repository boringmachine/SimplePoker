package edu.kcg.Poker;

public abstract class AdaptStrategy implements Strategy{
	abstract StrategyParams createStrategyParams();
}
