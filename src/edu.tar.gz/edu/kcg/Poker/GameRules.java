package edu.kcg.Poker;

public interface GameRules {

	public static final int FIRST=0,HUMAN=1,CHANCE=2,FINAL=3;
	
	public int gameStatus();
	public void firstPhase();
	public void chancePhase();
	public void humanPhase();
	public void finalPhase();
	public int nextPhase();
	
}
