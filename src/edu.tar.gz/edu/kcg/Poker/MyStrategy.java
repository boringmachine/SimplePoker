package edu.kcg.Poker;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MyStrategy implements Strategy{

	private static int serial = 0;
	private int id;
	public MyStrategy(){
		id = serial++;
	}
	
	@Override
	public int solveBet() {
		int bet=-2;
		try{
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			System.out.print(id + ":ベットを入力:");
			String line = in.readLine();
			bet = Integer.parseInt(line);
		}catch(Exception e){
			e.printStackTrace();
		}
		return bet;
	}


}
