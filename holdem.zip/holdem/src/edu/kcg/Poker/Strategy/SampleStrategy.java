package edu.kcg.Poker.Strategy;

public class SampleStrategy extends DefaultStrategy {
}
