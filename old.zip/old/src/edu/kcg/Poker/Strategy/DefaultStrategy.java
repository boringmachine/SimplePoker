package edu.kcg.Poker.Strategy;

public class DefaultStrategy extends AdaptStrategy {

	@Override
	public int solveRaise() {
		return 0;
	}

}
