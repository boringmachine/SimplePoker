package edu.kcg.Poker.Strategy;

public abstract class AdaptStrategy implements Strategy {
}
