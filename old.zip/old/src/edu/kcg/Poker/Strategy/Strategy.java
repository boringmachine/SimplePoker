package edu.kcg.Poker.Strategy;
/**
 * 戦略に最低限必要なメソッドを定義するインターフェイス.
 * 
 * @author Shun.S
 *
 */
public interface Strategy {
	int solveRaise();
}
